import heapq

graph = {}
heuristics = {}

def read_input_file(file_info):
    with open(file_info, 'r') as file:
        lines = file.readlines()

    for info in lines:
        city_info = info.split()
        node = city_info[0]
        heuristic_val = int(city_info[1])
        heuristics[node] = heuristic_val
        edges = {}
        for i in range(2, len(city_info), 2):
            neighbor = city_info[i]
            distance = int(city_info[i + 1])
            edges[neighbor] = distance
        graph[node] = edges

def AStar_Search(start, goal):
    pq_list = []
    heapq.heappush(pq_list, (heuristics[start], 0, start, [start]))
    explored_list = set()

    while pq_list:
        _, cost, current, path = heapq.heappop(pq_list)
        if current in explored_list:
            continue
        explored_list.add(current)

        if current == goal:
            return (cost, path)

        for neighbor, distance in graph[current].items():
            if neighbor not in explored_list:
                new_cost = cost + distance
                priority = new_cost + heuristics[neighbor]
                heapq.heappush(pq_list, (priority, new_cost, neighbor, path + [neighbor]))

    return None

def optimized_Romania_explore():

    read_input_file('Sabira_22101672_T1_input.txt')
    start = input("Start node: ")
    goal = input("Destination: ")

    optimized_path = AStar_Search(start, goal)

    with open('Sabira_22101672_T1_Output.txt', 'w') as output_file:
        if optimized_path:
            total_distance, path = optimized_path
            output_file.write(f"Path: {' -> '.join(path)}\n")
            output_file.write(f"Total distance: {total_distance} km\n")

        else:
            output_file.write("NO PATH FOUND\n")

optimized_Romania_explore()
